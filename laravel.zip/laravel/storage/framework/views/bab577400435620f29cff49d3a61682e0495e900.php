      <footer class="main-footer">
        <div class="pull-right hidden-xs">
          <?php echo trans('cms.version'); ?>

        </div>
        <strong><?php echo trans('cms.all.rights'); ?>

      </footer>