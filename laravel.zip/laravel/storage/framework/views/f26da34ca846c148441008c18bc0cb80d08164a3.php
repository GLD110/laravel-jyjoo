<div class="container">
    <div class="row">
        <div class="col-md-6 col-md-offset-3">
            <div class="panel panel-default">
                <div class="panel-heading">Login</div>
                <div class="panel-body">
                    <?php echo $__env->make('public::notifications', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php echo Form::vertical_open()
                    ->id('login')
                    ->method('POST')
                    ->action('login')
                    ->class('white-row'); ?>

                    <label for="email" class="control-label" style="color:#333;"><?php echo trans('user.user.label.email'); ?></label>
                    <?php echo Form::email('email','')
                    -> placeholder(trans('user.user.placeholder.email')); ?>

                    <label for="password" class="control-label" style="color:#333;"><?php echo trans('user.user.label.password'); ?></label>
                    <?php echo Form::password('password','')
                    -> placeholder(trans('user.user.placeholder.password')); ?>

                    <label for="rememberme" class="control-label" style="color:#333;">Remember me</label>
                    <?php echo Form::checkbox('rememberme', '')->inline(); ?>

                    <?php echo Form::submit(trans('user.signin'))->class('btn btn-primary'); ?>

                    <br>
                    <br>
                    <div class="row">
                        <div class="col-md-12" >
                            <a href="<?php echo URL::to('/login/facebook'); ?>" ><i class="fa fa-facebook fa-4"> </i></a> &nbsp;
                            <a href="<?php echo URL::to('/login/twitter'); ?>" ><i class="fa fa-twitter fa-4"> </i></a> &nbsp;
                            <a href="<?php echo URL::to('/login/google'); ?>" ><i class="fa fa-google-plus fa-4">  </i></a> &nbsp;
                            <a href="<?php echo URL::to('/login/linkedin'); ?>" ><i class="fa fa-linkedin fa-4"> </i></a> &nbsp;
                        </div>
                    </div>
                    <?php echo Form::close(); ?>

                    <font style="color:#333;">Forgot password?</font> <a href="<?php echo e(trans_url('/password/reset')); ?>"> Click to reset </a> <br>
                    <font style="color:#333;">Don't have an account yet?</font> <a href="<?php echo e(trans_url('/register')); ?>"> Click to create one </a>
                </div>
            </div>
        </div>
    </div>
</div>
