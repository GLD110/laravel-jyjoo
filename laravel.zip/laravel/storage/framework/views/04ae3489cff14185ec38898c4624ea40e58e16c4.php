
    <?php $i=0?>
    <?php while(isset($menu['0.' . ++$i])): ?>
    <?php if(($menu['0.' . $i]->parent)): ?>
    <li class="treeview <?php echo e(($menu['0.' . $i]->active) ?  'active' : ''); ?>">
        <a href="<?php echo e(URL::to($menu['0.' . $i]->url)); ?>" >
            <i class="<?php echo e(!empty($menu['0.' . $i]->icon) ?  $menu['0.' . $i]->icon : 'fa fa-angle-double-right'); ?>"></i> <span><?php echo e($menu['0.' . $i]->name); ?></span>
            <i class="fa fa-angle-left pull-right"></i>
        </a>
        <?php echo $__env->make('menu.sub.admin', array('menu' => $menu, 'key' => '0.' . $i), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </li>
    <?php else: ?>
    <li  <?php echo e(($menu['0.' . $i]->active == 'active') ?  'class="active"' : ''); ?>>
        <a href="<?php echo e(URL::to($menu['0.' . $i]->url)); ?>">
            <i class="<?php echo e(!empty($menu['0.' . $i]->icon) ?  $menu['0.' . $i]->icon : 'fa fa-angle-double-right'); ?>"></i>
            <span><?php echo e($menu['0.' . $i]->name); ?></span>
        </a>
    </li>
    <?php endif; ?>
    <?php endwhile; ?>

