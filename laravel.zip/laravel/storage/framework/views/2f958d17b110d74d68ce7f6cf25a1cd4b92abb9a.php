<!-- resources/views/auth/register.blade.php -->
<div class="container">
    <div class="row">
        <div class="col-md-6  col-md-offset-3">
            <div class="panel panel-default">
                <div class="panel-heading">Register</div>
                <div class="panel-body">
                    <?php echo $__env->make('public::notifications', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php echo Form::vertical_open()
                    ->id('contact')
                    ->action('register')
                    ->method('POST')
                    ->class('white-row'); ?>


                    <?php echo Form::text('name')
                    -> label(trans('user.user.label.name'))
                    -> placeholder(trans('user.user.placeholder.name')); ?>


                    <?php echo Form::email('email')
                    -> label(trans('user.user.label.email'))
                    -> placeholder(trans('user.user.placeholder.email')); ?>


                    <?php echo Form::password('password')
                    -> label(trans('user.user.label.password'))
                    -> placeholder(trans('user.user.placeholder.password')); ?>


                    <?php echo Form::hidden('role')->value($role); ?>


                    <?php echo Captcha::render(); ?>

                    <br />
                    <?php echo Form::submit(trans('user.signin'))->class('btn btn-primary'); ?>

                    <br>
                    <br>

                    <?php echo Form::close(); ?>

                    Already have an account ! <a href="<?php echo e(trans_url('/login')); ?>"> Click to login </a>
                </div>
            </div>
        </div>
    </div>
</div>
