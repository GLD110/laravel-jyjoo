<ul class="treeview-menu <?php echo e(($menu[$key]->active) ?  'active' : ''); ?>">
    <?php $i=0?>
    <?php while(isset($menu[$key . '.' . ++$i])): ?>
    <?php if(($menu[$key . '.' . $i]->parent)): ?>
    <li class="treeview <?php echo e(($menu[$key . '.' . $i]->active) ?  'active' : ''); ?>">
        <a href="<?php echo e(URL::to($menu[$key . '.' . $i]->url)); ?>" >
            <i class="<?php echo e(!empty($menu[$key . '.' . $i]->icon) ?  $menu[$key . '.' . $i]->icon : 'fa fa-angle-double-right'); ?>"></i> <span><?php echo e($menu[$key . '.' . $i]->name); ?></span>
            <i class="fa fa-angle-left pull-right"></i>
        </a>
        <?php echo $__env->make('menu.sub.admin', array('menu' => $menu, 'key' => $key . '.' . $i), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </li>
    <?php else: ?>
    <li  <?php echo e(($menu[$key . '.' . $i]->active) ?  'class="active"' : ''); ?>>
        <a href="<?php echo e(URL::to($menu[$key . '.' . $i]->url)); ?>">
            <i class="<?php echo e(!empty($menu[$key . '.' . $i]->icon) ?  $menu[$key . '.' . $i]->icon : 'fa fa-angle-double-right'); ?>"></i>
            <span><?php echo e($menu[$key . '.' . $i]->name); ?></span>
        </a>
    </li>
    <?php endif; ?>
    <?php endwhile; ?>
</ul>
