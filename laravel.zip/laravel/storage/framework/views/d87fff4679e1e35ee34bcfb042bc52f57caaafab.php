 <div id="wrap">
    <nav class="navbar navbar-default navbar-static-top">
        <div class="container">
            <div id="navbar">
                <ul class="nav navbar-links pull-right" id="js-buttons">
                    <?php if(Auth::check()): ?>
                        <li>
                            <a href="<?php echo e(trans_url('home')); ?>">
                                <span class="hidden-xs"><?php echo e(get_users('name')); ?></span>
                                <span class="hidden-sm hidden-md hidden-lg"><i class="fa fa-user"></i></span>
                            </a>
                        </li>
                        <?php if(app('user')->hasRoles('admin')): ?>
                        <li>
                            <a href="<?php echo e(trans_url('admin')); ?>">
                                <span class="hidden-xs">Admin</span>
                                <span class="hidden-sm hidden-md hidden-lg"><i class="fa fa-cog"></i></span>
                            </a>
                        </li>
                        <?php endif; ?>
                        <li>
                            <a href="<?php echo e(trans_url('logout')); ?>">
                                <span class="hidden-xs">Logout</span>
                                <span class="hidden-sm hidden-md hidden-lg"><i class="fa fa-sign-out"></i></span>
                            </a>
                        </li>
                    <?php else: ?>
                        <li>
                            <a href="<?php echo e(trans_url('register')); ?>">
                                <span class="hidden-xs">Register</span>
                                <span class="hidden-sm hidden-md hidden-lg"><i class="fa fa-user"></i></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(trans_url('login')); ?>">
                                <span class="hidden-xs">Login</span>
                                <span class="hidden-sm hidden-md hidden-lg"><i class="fa fa-sign-in"></i></span>
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
            <div class="navbar-header">
             <a class="navbar-brand" href="<?php echo e(trans_url('/')); ?>"> <img src="<?php echo e(asset('img/logo/default.png')); ?>" alt="Lavalite"> </a>
            </div>
        </div>
    </nav>
</div>
