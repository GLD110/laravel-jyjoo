<!DOCTYPE html>
<html class="lockscreen">
    <head>
        <meta charset="UTF-8">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title><?php echo e(Theme::getTitle()); ?></title>
        <meta name="description" content="The Lavalite Content Management System">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="apple-touch-icon" href="<?php echo e(asset('apple-touch-icon.png')); ?>">
        <link href="<?php echo e(asset('css/vendor_public.css')); ?>" rel="stylesheet">

        <?php echo Theme::asset()->styles(); ?>

        <?php echo Theme::asset()->scripts(); ?>

    </head>

<body class="user">

    <?php echo Theme::partial('header'); ?>

    <div class="container-fluid content">
        <div style="min-height:500px;">
            <div class="row">
                <div class="col-md-3 col-lg-3 menu">
                    <?php echo Theme::partial('user'); ?>

                </div>
                <div class="col-md-9 col-lg-9 body">
                    <?php echo Theme::content(); ?>

                </div>
            </div>
        </div>
    </div>
    <?php echo Theme::partial('footer'); ?>

    <script src="<?php echo e(asset('js/vendor_public.js')); ?>"></script>
    <script src="<?php echo e(asset('js/public.js')); ?>"></script>
    <?php echo Theme::asset()->container('footer')->scripts(); ?>

</body>
</html>
