<?php $__env->startSection('heading'); ?>
<i class="fa fa-file-text-o"></i> <?php echo trans('settings::setting.name'); ?> <small> <?php echo trans('cms.manage'); ?> <?php echo trans('settings::setting.names'); ?></small>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
<?php echo trans('settings::setting.names'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<ol class="breadcrumb">
    <li><a href="<?php echo URL::to('admin'); ?>"><i class="fa fa-dashboard"></i> <?php echo trans('cms.home'); ?> </a></li>
    <li class="active"><?php echo trans('settings::setting.names'); ?></li>
</ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('entry'); ?>
<div class="box box-warning" id='entry-setting'>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('tools'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<table id="main-list" class="table table-striped table-bordered">
    <thead>
        <th><?php echo trans('settings::setting.label.skey'); ?></th>
        <th><?php echo trans('settings::setting.label.name'); ?></th>
        <th><?php echo trans('settings::setting.label.value'); ?></th>
        <th><?php echo trans('settings::setting.label.type'); ?></th>
    </thead>
</table>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script type="text/javascript">

var oTable;
$(document).ready(function(){
    app.load('#entry-setting','<?php echo e(trans_url('/admin/settings/setting/0')); ?>');
    oTable = $('#main-list').dataTable({
        "ajax": '<?php echo e(trans_url('/admin/settings/setting')); ?>',
        "columns": [
        { "data": "skey" },
        { "data": "name" },
        { "data": "value" },
        { "data": "type" },],
        "settingLength": 50
    });

    $('#main-list tbody').on( 'click', 'tr', function () {
        if ( $(this).hasClass('selected') ) {
            $(this).removeClass('selected');
        } else {
            oTable.$('tr.selected').removeClass('selected');
            $(this).addClass('selected');
        }

        var d = $('#main-list').DataTable().row( this ).data();
        app.load('#entry-setting', '<?php echo e(trans_url('/admin/settings/setting')); ?>' + '/' + d.id);

    });
});
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin::curd.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>