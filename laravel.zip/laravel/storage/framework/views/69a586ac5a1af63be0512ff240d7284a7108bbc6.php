<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
        <?php $__env->startSection('heading'); ?> Heading <?php echo $__env->yieldSection(); ?>
        </h1>
        <?php $__env->startSection('breadcrumb'); ?> Breadcrumb <?php echo $__env->yieldSection(); ?>
    </section>
    <!-- Main content -->
    <section class="content">
    <?php $__env->startSection('entry'); ?> 
        <div class="box box-warning" id='entry'>
        </div>
    <?php echo $__env->yieldSection(); ?>
        <!-- Default box -->
        <div class="box box-primary">
            <div class="box-header with-border">
                <h3 class="box-title">
                <?php $__env->startSection('title'); ?> Entry <?php echo $__env->yieldSection(); ?></h3>
                <div class="box-tools pull-right">
                    <?php $__env->startSection('tools'); ?> Tools <?php echo $__env->yieldSection(); ?>
                </div>
            </div>
            <div class="box-body">
                <?php $__env->startSection('content'); ?> Content <?php echo $__env->yieldSection(); ?>
            </div>
        </div>
    </section>
</div>
<?php $__env->startSection('script'); ?>

<?php echo $__env->yieldSection(); ?>

<?php $__env->startSection('style'); ?>

<?php echo $__env->yieldSection(); ?> 